from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/v1/modules')
def get_modules():
    data = [
        {"id": 1, "title": "Coffee Brewing Standards", "status": "complete"},
        {"id": 2, "title": "Guest Greeting & First Impression", "status": "in-progress"},
        {"id": 3, "title": "Safety & Cleanliness Basics", "status": "not started"}
    ]
    return jsonify(data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
