# Élan API (Mock)
This lightweight Flask API serves mock training modules for the Élan Training Portal MVP.
